
import numpy as np
from typing import Dict, Tuple
from .state import QState, HilbertSpace
from .ops import projector

def born_prob(rho: np.ndarray, M: np.ndarray) -> float:
    return float(np.real(np.trace(rho @ M)))

def measure_projective(s: QState, H: HilbertSpace, basis_labels: Dict[str, float]) -> Tuple[str, float, QState]:
    # basis_labels: mapping label -> eigenvalue (not used in sampling)
    povm = {lbl: projector(H, lbl) for lbl in basis_labels.keys()}
    # probabilities
    ps = {k: born_prob(s.rho, E) for k,E in povm.items()}
    labels, probs = zip(*ps.items())
    probs = np.maximum(probs, 0); probs = probs/np.sum(probs)
    outcome = np.random.choice(labels, p=probs)
    P = povm[outcome]
    rho_post = P @ s.rho @ P
    p = float(np.real(np.trace(rho_post)))
    rho_post = rho_post / (p if p>0 else 1.0)
    return outcome, float(np.real(ps[outcome])), QState(s.H, rho_post)
