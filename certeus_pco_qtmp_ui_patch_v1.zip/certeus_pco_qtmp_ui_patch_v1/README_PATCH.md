
# CERTEUS: PCO × QTMP × UI Patch v1.0

This patch delivers:
- **Schemas**: boundary_event_v1, qtm_event_v1, cfe_metrics_v1
- **PCO helper**: `pco/pco_envelope.py`
- **Services**: `services/qtm_service`, `services/cfe_service` (FastAPI stubs)
- **OpenAPI**: `openapi/openapi.yaml`
- **UI**: `ui/MeasurementPanel.tsx` (drop-in React component)
- **CI gates**: gauge, boundary-rebuild, path-coverage (stubs)
- **Devices**: horizon drive / quantum oracle / entanglement inducer / chrono-infudibulum stubs

## How to wire into existing monorepo
1) Copy `schemas/*.json` into your repo `schemas/` and register in your PCO validator.
2) Add `services/qtm_service` and `services/cfe_service` to your docker-compose; expose `/v1/qtm/*` and `/v1/cfe/*` via API Gateway.
3) Import `ui/MeasurementPanel.tsx` in your console (React) and set `apiBase` to your gateway URL.
4) Emit PCO envelopes with `pco/pco_envelope.py` for each `/v1/qtm/measure` call; store to boundary ledger.
5) Enable CI gates in `.github/workflows/*` and fill in scripts that call your services.
6) Extend per-domain packs (law/finance/etc.) to construct operators (W/I/C/L/T) and amplitudes from real data.

## Telemetry
Ensure you persist in PCO:
- `qtm.collapse_outcome`, `qtm.collapse_prob`, `qtm.collapse_latency_ms`,
- `qtm.uncertainty_bound.*`, `qtm.entanglement.*`,
- `cfe.R`, `cfe.Ricci_max`, `cfe.kappa_max`, `cfe.geodesic_action`, `cfe.lapse_N`.

## Notes
- FastAPI stubs are minimal; replace placeholder math with your `modules/cfe`/`modules/qtm` engines.
- The UI component is framework-agnostic (React+TS). Tailwind classes included but optional.
