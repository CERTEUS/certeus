AXIOMLOG – szkic.
