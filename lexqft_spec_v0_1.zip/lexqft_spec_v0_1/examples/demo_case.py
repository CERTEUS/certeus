
from lexqft import compile, calibrate, sample, geodesic, horizon, lensing

# toy graph placeholder
graph = {"nodes": ["fact:A","norm:B","precedent:C"], "edges": [("A","B"),("B","C")]}
llex = compile(graph)
llex = calibrate(llex, data={"outcomes":[]})
print("sample:", sample(llex, 10000))
print("geodesic:", geodesic(llex))
print("horizon:", horizon(llex))
print("lensing:", lensing(llex, "precedent:C"))
