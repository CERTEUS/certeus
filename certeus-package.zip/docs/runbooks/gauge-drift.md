# Runbook: Gauge drift > ε
1) Przejrzyj transformacje Ω-Kernel (lang/jurisdiction/revision).
2) Uzupełnij/napraw mapowania (bridges).
3) Powtórz Gauge-Gate w CI z `--epsilon 1e-3`. 