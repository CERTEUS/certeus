
import json, hashlib, time
from typing import Dict

def canonical(obj: Dict) -> str:
    return json.dumps(obj, separators=(",",":"), sort_keys=True, ensure_ascii=False)

def make_envelope(payload: Dict, upn: str, privkey_stub: str="ed25519:stub") -> Dict:
    body = {
        "upn": upn,
        "payload": payload,
        "ts": int(time.time()*1000)
    }
    c = canonical(body).encode("utf-8")
    h = hashlib.sha256(c).hexdigest()
    # NOTE: replace with real signature; this is a stub.
    sig = f"{privkey_stub}:{h}"
    return {"proof_envelope":{"hash":"sha256:"+h,"sig":sig},"body":body}
