Metryki – szkic.
