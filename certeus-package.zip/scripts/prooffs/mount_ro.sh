#!/usr/bin/env bash
# +-------------------------------------------------------------+
# | CERTEUS - ProofFS mount (read-only)                         |
# +-------------------------------------------------------------+
set -Eeuo pipefail
echo "[i] This is a placeholder for mounting pfs:// as read-only."
echo "[i] Implement driver or sidecar according to your environment."
