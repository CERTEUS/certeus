Mismatch Console – szkic.
