OPA – szkic.
