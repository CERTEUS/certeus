OPTLOG – szkic.
