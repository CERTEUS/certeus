instrumentation_bridge – stub
