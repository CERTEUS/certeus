Helm chart – szkic.
