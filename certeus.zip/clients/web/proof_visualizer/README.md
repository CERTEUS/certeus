Proof Visualizer – szkic.
