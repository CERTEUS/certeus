Handbook inżynierii wiedzy (EVIDENCE-LOG, klasy metadanych).
