Instalacja, uv/pip, uruchomienie.
