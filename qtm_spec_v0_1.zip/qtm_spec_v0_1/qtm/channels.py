
import numpy as np
from typing import List
from .state import QState

def _apply_kraus(rho: np.ndarray, K: List[np.ndarray]) -> np.ndarray:
    out = sum([Kk @ rho @ Kk.conj().T for Kk in K])
    # renormalize trace to 1 if numerical drift
    tr = np.trace(out)
    if np.real(tr) > 0:
        out = out / np.real(tr)
    return out

def dephasing(s: QState, p: float) -> QState:
    # single-qubit style dephasing generalized to d-dim by Z in computational basis
    d = s.rho.shape[0]
    Z = np.diag([1 if i%2==0 else -1 for i in range(d)]).astype(complex)
    K = [np.sqrt(1-p)*np.eye(d, dtype=complex), np.sqrt(p)*Z]
    return QState(s.H, _apply_kraus(s.rho, K))

def depolarizing(s: QState, lam: float) -> QState:
    d = s.rho.shape[0]
    I = np.eye(d, dtype=complex)
    out = (1-lam)*s.rho + lam*I/d
    out = out/np.trace(out)
    return QState(s.H, out)
