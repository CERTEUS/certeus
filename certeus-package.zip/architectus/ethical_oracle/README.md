ethical_oracle – stub
