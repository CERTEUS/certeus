axiom_modulator – stub
