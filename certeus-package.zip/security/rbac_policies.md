Role: Architect, Proof‑Engineer, LKEW, Ops.
