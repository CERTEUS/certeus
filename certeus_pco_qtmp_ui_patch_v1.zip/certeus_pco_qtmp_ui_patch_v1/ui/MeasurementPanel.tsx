
import React, { useState } from "react";

type Props = { apiBase?: string };

export const MeasurementPanel: React.FC<Props> = ({ apiBase = "" }) => {
  const [caseId, setCaseId] = useState("");
  const [allow, setAllow] = useState("1+0j");
  const [deny, setDeny] = useState("1j");
  const [abstain, setAbstain] = useState("0.2");
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const measure = async () => {
    setLoading(true);
    try {
      const body = {
        case_id: caseId || "demo",
        basis: ["ALLOW","DENY","ABSTAIN"],
        amplitudes: { ALLOW: allow, DENY: deny, ABSTAIN: abstain },
        operator: "W",
        observer: "ui:measurement-panel"
      };
      const r = await fetch(apiBase + "/v1/qtm/measure", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body)
      });
      const j = await r.json();
      setResult(j.qtm_event || j);
    } finally { setLoading(false); }
  };

  return (
    <div className="p-4 rounded-2xl shadow">
      <h3 className="text-xl font-semibold mb-2">Quantum Measurement (QTMP)</h3>
      <div className="grid grid-cols-2 gap-2 mb-3">
        <label className="col-span-2">Case ID
          <input className="w-full border p-2 rounded" value={caseId} onChange={e=>setCaseId(e.target.value)} />
        </label>
        <label>ALLOW amplitude
          <input className="w-full border p-2 rounded" value={allow} onChange={e=>setAllow(e.target.value)} />
        </label>
        <label>DENY amplitude
          <input className="w-full border p-2 rounded" value={deny} onChange={e=>setDeny(e.target.value)} />
        </label>
        <label>ABSTAIN amplitude
          <input className="w-full border p-2 rounded" value={abstain} onChange={e=>setAbstain(e.target.value)} />
        </label>
      </div>
      <button onClick={measure} className="px-4 py-2 rounded bg-black text-white" disabled={loading}>
        {loading ? "Measuring..." : "Measure Verdict"}
      </button>
      {result && (
        <pre className="mt-3 bg-gray-100 p-3 rounded text-sm overflow-auto">{JSON.stringify(result, null, 2)}</pre>
      )}
    </div>
  );
};
export default MeasurementPanel;
