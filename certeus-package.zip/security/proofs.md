External Proof Checking (DRAT/LFSC) – zasady publikacji.
