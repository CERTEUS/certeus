IaC – szkic.
