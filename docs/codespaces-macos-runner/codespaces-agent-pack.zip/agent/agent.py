# ============================================================================
#  CODESPACES-AGENT PACK  |  ForgeHeader v1
#  PL: Automatyczny agent do uruchomienia z GitHub Codespaces (or DevContainer)
#      – konfiguruje zdalne hosty (Linux/macOS/Windows) i rejestruje
#      self-hosted runnera GitHub Actions. Bez czarnych skrzynek.
#  EN: Turnkey agent to run from Codespaces/DevContainer to bootstrap
#      remote hosts (Linux/macOS/Windows) and register a GitHub Actions
#      self-hosted runner. Zero magic, all scripts included.
#
#  File      : agent/agent.py
#  Author    : Radosław Skarżycki (Radziu)
#  Version   : 0.1.0
#  Date (UTC): 2025-09-06T17:33:09Z
#  License   : MIT
#  Repo      : <your-repo-here>
#  Commit    : <fill-after-commit>
# ============================================================================

"""
PL: Agent do uruchamiania z Codespaces/DevContainer.
 - Rejestruje self-hosted runnera na zdalnym Linux/macOS (przez SSH+Ansible).
 - Drukuje jednorazowy skrypt PowerShell dla Windows (z tokenem).

EN: Run from Codespaces/DevContainer.
 - Registers a self-hosted runner on remote Linux/macOS (SSH+Ansible).
 - Prints a one-time Windows PowerShell script (with token).
"""
from __future__ import annotations
import argparse, base64, json, os, subprocess, sys, tempfile, textwrap
from pathlib import Path

import requests  # installed in devcontainer

GITHUB_API = os.environ.get("GITHUB_API", "https://api.github.com")

def die(msg: str, code: int = 1):
    print(f"[ERROR] {msg}", file=sys.stderr)
    sys.exit(code)

def get_repo():
    repo = os.environ.get("GITHUB_REPOSITORY")
    if not repo or "/" not in repo:
        die("Set GITHUB_REPOSITORY=OWNER/REPO")
    return repo

def get_token():
    token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
    if not token:
        die("Set GH_TOKEN (or GITHUB_TOKEN) with 'repo' and 'workflow' scopes")
    return token

def gh_runner_registration_token(repo: str, token: str) -> dict:
    url = f"{GITHUB_API}/repos/{repo}/actions/runners/registration-token"
    r = requests.post(url, headers={"Authorization": f"Bearer {token}",
                                    "Accept": "application/vnd.github+json"})
    if r.status_code != 201:
        die(f"GitHub API error: {r.status_code} {r.text}")
    return r.json()  # includes 'token', 'expires_at'

def run(cmd: list[str], check=True, env=None):
    print(f"[RUN] {' '.join(cmd)}")
    return subprocess.run(cmd, check=check, env=env)

def write_tmp_inventory(host: str, user: str, port: int = 22) -> Path:
    inv = textwrap.dedent(f"""
    [target]
    {host} ansible_user={user} ansible_port={port}
    """).strip()
    p = Path(tempfile.mkstemp(prefix="inventory_", suffix=".ini")[1])
    p.write_text(inv, encoding="utf-8")
    return p

def setup_runner_unix(ansible_playbook: str, host: str, user: str, label: str, repo: str, token: str, port: int = 22, docker: bool = True):
    inv = write_tmp_inventory(host, user, port)
    extra = json.dumps({"github_repo": repo, "runner_token": token, "runner_labels": label, "install_docker": docker})
    run(["ansible-playbook", "-i", str(inv), ansible_playbook, "--extra-vars", extra])

def print_windows_runner_script(label: str, repo: str, token: str):
    # On Windows, user will paste this in *elevated* PowerShell.
    ps = textwrap.dedent(f"""
    # ===================== GITHUB RUNNER – WINDOWS (Admin) =====================
    # Repo   : {repo}
    # Labels : {label}
    # Token  : ephemeral (expires soon)
    # Steps  : Run in *Administrator* PowerShell

    $ErrorActionPreference = "Stop"

    function Ensure-Admin {{
      $wid = [System.Security.Principal.WindowsIdentity]::GetCurrent()
      $prp = New-Object System.Security.Principal.WindowsPrincipal($wid)
      if (-not $prp.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {{
        Write-Error "Run this script in an *Administrator* PowerShell."
      }}
    }}
    Ensure-Admin

    # 1) OpenSSH Server (for future SSH)
    Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0 | Out-Null
    Start-Service sshd
    Set-Service -Name sshd -StartupType 'Automatic'
    if (-not (Get-NetFirewallRule -Name "OpenSSH-Server-In-TCP" -ErrorAction SilentlyContinue)) {{
      New-NetFirewallRule -Name "OpenSSH-Server-In-TCP" -DisplayName "OpenSSH Server (sshd)" -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22 | Out-Null
    }}

    # 2) Create runner directory
    $RunnerDir = "C:\\actions-runner"
    New-Item -ItemType Directory -Force -Path $RunnerDir | Out-Null
    Set-Location $RunnerDir

    # 3) Download latest runner
    $arch = "x64"
    $ver = (Invoke-RestMethod -Uri "https://api.github.com/repos/actions/runner/releases/latest").tag_name.TrimStart('v')
    $zip = "actions-runner-win-$arch-$ver.zip"
    Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/actions/runner/releases/download/v$ver/$zip" -OutFile $zip

    # 4) Extract
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $RunnerDir, $true)

    # 5) Configure and install as service
    .\\config.cmd --unattended --url https://github.com/{repo} --token {token} --labels "{label}" --runasservice
    .\\run.cmd
    # To manage service later:
    # .\\svc install; .\\svc start; .\\svc status
    """)
    print(ps)

def main():
    ap = argparse.ArgumentParser(description="Codespaces Agent (self-hosted runners)")
    sub = ap.add_subparsers(dest="cmd")

    # linux/mac
    sp_u = sub.add_parser("--setup-runner", help="Setup runner on UNIX (Linux/macOS) via SSH+Ansible")
    sp_u.add_argument("os", choices=["linux", "mac"], help="Target OS")
    sp_u.add_argument("--host", required=True, help="Target host/IP")
    sp_u.add_argument("--user", required=True, help="SSH user")
    sp_u.add_argument("--port", type=int, default=22, help="SSH port (default 22)")
    sp_u.add_argument("--label", default="self-hosted", help="Runner label to attach")
    sp_u.add_argument("--no-docker", action="store_true", help="Skip Docker/Colima install on macOS/Linux")

    # windows helper
    sp_w = sub.add_parser("--print-win-runner-script", help="Print one-time Windows runner script (PowerShell)")
    sp_w.add_argument("--label", default="self-hosted", help="Runner label to attach")

    args = ap.parse_args()
    repo = get_repo()
    token = get_token()
    reg = gh_runner_registration_token(repo, token)
    runner_token = reg.get("token")

    if args.cmd == "--setup-runner":
        docker = not args.no_docker
        if args.os == "linux":
            setup_runner_unix("agent/playbooks/linux-runner.yml", args.host, args.user, args.label, repo, runner_token, port=args.port, docker=docker)
        else:
            setup_runner_unix("agent/playbooks/macos-runner.yml", args.host, args.user, args.label, repo, runner_token, port=args.port, docker=docker)
        print("\n[OK] Runner zainstalowany. Sprawdź Settings → Actions → Runners.")
    elif args.cmd == "--print-win-runner-script":
        print_windows_runner_script(args.label, repo, runner_token)
    else:
        ap.print_help()

if __name__ == "__main__":
    main()
