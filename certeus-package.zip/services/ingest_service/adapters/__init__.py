# =============================================================================
#  CERTEUS — adapters package
#  PL: Adaptery (Preview/OCR/Drive/LLM).
#  EN: Adapters (Preview/OCR/Drive/LLM).
# =============================================================================
"""
PL: Pakiet adapterów (Preview/OCR/Drive/LLM).
EN: Adapters package (Preview/OCR/Drive/LLM).
"""
