
# lexqft-spec v0.1 — Standard Model of Law (CERTEUS)

This is a skeleton API to operationalize the quantum-field view of legal reasoning.

## API
See `lexqft/api.py` for stubs:
- compile(case_graph) -> LLEX
- calibrate(LLEX, data) -> fitted params
- sample(LLEX, N) -> verdict distribution & interference
- geodesic(LLEX) -> geodesic proof path
- horizon(LLEX) -> (locked, mass)
- lensing(LLEX, source) -> deflection vector

Artifacts map to your PCO telemetry fields: `cfe.*`, `pi.*`, `boundary.*`.
