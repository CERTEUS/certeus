
from fastapi import FastAPI
from pydantic import BaseModel
from typing import Dict, List, Optional
import numpy as np
from datetime import datetime, timezone

# Minimal QTM utils embedded
class HilbertSpace:
    def __init__(self, basis: List[str]): self.basis=basis

def projector(H: HilbertSpace, label: str):
    d=len(H.basis); i=H.basis.index(label); e=np.zeros((d,1),dtype=complex); e[i,0]=1.0
    return e@e.conj().T

def pure_state(H: HilbertSpace, amps: Dict[str, complex]):
    d=len(H.basis); psi=np.zeros((d,1),dtype=complex)
    for k,v in amps.items(): psi[H.basis.index(k),0]=complex(v)
    n=np.linalg.norm(psi); psi=psi/n if n!=0 else psi; return psi@psi.conj().T

def born_prob(rho, M): return float(np.real(np.trace(rho@M)))

def measure_projective(rho, H: HilbertSpace):
    povm={lbl: projector(H,lbl) for lbl in H.basis}
    ps={k: born_prob(rho,E) for k,E in povm.items()}
    labels, probs = zip(*ps.items())
    probs = np.maximum(probs, 0); probs = probs/np.sum(probs) if np.sum(probs)>0 else np.ones_like(probs)/len(probs)
    outcome = np.random.choice(labels, p=probs)
    P = povm[outcome]
    rho_post = P@rho@P
    p = float(np.real(np.trace(rho_post)))
    rho_post = rho_post/(p if p>0 else 1.0)
    return outcome, float(ps[outcome]), rho_post

class MeasureReq(BaseModel):
    case_id: str
    basis: List[str] = ["ALLOW","DENY","ABSTAIN"]
    amplitudes: Dict[str, complex]
    operator: str = "W"   # W/I/C/L/T
    observer: Optional[str] = "system:qtm_service"
    decoherence_channel: Optional[str] = None

app = FastAPI(title="CERTEUS QTMP Service", version="1.0")

@app.post("/v1/qtm/measure")
def measure(req: MeasureReq):
    H = HilbertSpace(req.basis)
    rho = pure_state(H, req.amplitudes)
    outcome, p, rho_post = measure_projective(rho, H)
    evt = {
        "case_id": req.case_id,
        "operator": req.operator,
        "basis": "verdict",
        "outcome": outcome,
        "prob": p,
        "t": datetime.now(timezone.utc).isoformat(),
        "observer": req.observer,
        "telemetry":{
            "collapse_latency_ms": 0.0,
            "uncertainty_lower_bound": None,
            "decoherence_channel": req.decoherence_channel,
            "entanglement_mi": None,
            "entanglement_negativity": None
        }
    }
    return {"qtm_event": evt}
