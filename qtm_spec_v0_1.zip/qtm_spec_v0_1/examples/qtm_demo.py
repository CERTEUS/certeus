
import numpy as np
from qtm.state import HilbertSpace, pure_state
from qtm.ops import hermitian_from_eigs, commutator, uncertainty_lower_bound
from qtm.measure import measure_projective
from qtm.channels import dephasing

# Hilbert space over verdicts
H = HilbertSpace(["ALLOW","DENY","ABSTAIN"])

# Superposed case state
s = pure_state(H, {"ALLOW": 1+0j, "DENY": 1j, "ABSTAIN": 0.2})

# Observables (eigen-values don't change sampling here, but define operator)
W = hermitian_from_eigs(H, {"ALLOW": +1, "DENY": -1, "ABSTAIN": 0})
L = hermitian_from_eigs(H, {"ALLOW": 0.9, "DENY": 0.1, "ABSTAIN": 0.5})
T = hermitian_from_eigs(H, {"ALLOW": 0.2, "DENY": 0.8, "ABSTAIN": 0.6})

# Uncertainty bound for (L,T)
lb = uncertainty_lower_bound(s.rho, L, T)
print("Uncertainty lower bound ΔL·ΔT ≥", lb)

# Measure verdict (collapse)
outcome, p, s2 = measure_projective(s, H, {"ALLOW":+1,"DENY":-1,"ABSTAIN":0})
print("Measured verdict:", outcome, "with p≈", round(p,3))

# Decoherence (public exposure)
s3 = dephasing(s2, p=0.3)
print("Post-decoherence state trace≈", np.trace(s3.rho).real)
