
import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Tuple

@dataclass
class HilbertSpace:
    basis: List[str]  # e.g., ["ALLOW","DENY","ABSTAIN"]

@dataclass
class QState:
    H: HilbertSpace
    rho: np.ndarray  # density matrix (d x d), Hermitian PSD, tr=1

def pure_state(H: HilbertSpace, amplitudes: Dict[str, complex]) -> QState:
    d = len(H.basis)
    psi = np.zeros((d,1), dtype=complex)
    for k,(label,amp) in enumerate(amplitudes.items()):
        i = H.basis.index(label)
        psi[i,0] = amp
    norm = np.linalg.norm(psi)
    if norm == 0: raise ValueError("Zero state")
    psi /= norm
    rho = psi @ psi.conj().T
    return QState(H, rho)

def mixed_from_probs(H: HilbertSpace, probs: Dict[str, float]) -> QState:
    d = len(H.basis)
    rho = np.zeros((d,d), dtype=complex)
    for label,p in probs.items():
        i = H.basis.index(label)
        e = np.zeros((d,1), dtype=complex); e[i,0]=1.0
        rho += p * (e @ e.conj().T)
    return QState(H, rho/np.trace(rho))

def trace_distance(a: QState, b: QState) -> float:
    # 0.5 * ||rho_a - rho_b||_1  (approx via eigvals of Hermitian difference)
    D = a.rho - b.rho
    vals = np.linalg.eigvalsh((D + D.conj().T)/2.0)
    return 0.5*float(np.sum(np.abs(vals)))
