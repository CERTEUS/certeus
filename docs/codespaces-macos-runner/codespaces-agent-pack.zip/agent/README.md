# ============================================================================
#  CODESPACES-AGENT PACK  |  ForgeHeader v1
#  PL: Automatyczny agent do uruchomienia z GitHub Codespaces (or DevContainer)
#      – konfiguruje zdalne hosty (Linux/macOS/Windows) i rejestruje
#      self-hosted runnera GitHub Actions. Bez czarnych skrzynek.
#  EN: Turnkey agent to run from Codespaces/DevContainer to bootstrap
#      remote hosts (Linux/macOS/Windows) and register a GitHub Actions
#      self-hosted runner. Zero magic, all scripts included.
#
#  File      : agent/README.md
#  Author    : Radosław Skarżycki (Radziu)
#  Version   : 0.1.0
#  Date (UTC): 2025-09-06T17:31:49Z
#  License   : MIT
#  Repo      : <your-repo-here>
#  Commit    : <fill-after-commit>
# ============================================================================

# Codespaces Agent – Quick Start

> **PL:** GitHub Codespaces **nie** uruchomi natywnie Windows/macOS. Ten agent
> działa w Codespaces i **zdalnie** konfiguruje Twoje fizyczne hosty (Windows/macOS/Linux)
> oraz rejestruje je jako **self‑hosted runners** dla GitHub Actions – czyli
> masz buildy/testy na prawdziwym OS bez płacenia za Codespaces minuty.
>
> **EN:** Codespaces can't run native Windows/macOS. This agent runs *inside*
> Codespaces and configures your physical hosts remotely, registering them
> as **self-hosted runners** for GitHub Actions.

---

## 0) Przygotowanie w Codespaces
1. Otwórz repo w **GitHub Codespaces** (albo lokalnie jako DevContainer).
2. Upewnij się, że masz token z uprawnieniami `repo` i `workflow`:
   ```bash
   export GH_TOKEN=ghp_xxx   # lub użyj `gh auth login`
   ```
3. Ustaw repo docelowe (owner/repo), na które mają rejestrować się runnery:
   ```bash
   export GITHUB_REPOSITORY=OWNER/REPO
   ```

## 1) Linux/macOS – pełen auto‑setup przez SSH + Ansible
Masz publiczny adres lub dostęp po VPN/SSH? Jednym poleceniem uruchom runnera na zdalnej maszynie.

### Linux (przykład)
```bash
python agent/agent.py --setup-runner linux --host 203.0.113.10 --user radziu --label "linux-x64"
```

### macOS (przykład)
```bash
python agent/agent.py --setup-runner mac --host 203.0.113.20 --user radziu --label "macos-x64"
```

Agent:
- Pobierze **ephemeral token** rejestracyjny z GitHuba,
- Zaloguje się przez SSH,
- Zainstaluje runnera i uruchomi go jako usługę (`svc.sh install && start`).

> **Uwaga (macOS):** Playbook używa `brew` i instaluje `colima` + `docker` CLI,
> aby opcjonalnie wspierać *devcontainers* bez Docker Desktop. Możesz pominąć ten krok flagą `--no-docker`.

## 2) Windows – skrypt jednorazowy, potem agent dokończy
Na Windows pierwszy krok to włączenie remoting (OpenSSH/WinRM). Wygeneruj komendę z tokenem:
```bash
python agent/agent.py --print-win-runner-script --label "win-x64"
```
Skopiuj **wydrukowany** blok PowerShell na maszynę Windows (uruchom *jako Administrator*).
Skrypt:
- włączy OpenSSH Server,
- doda Twój klucz SSH (jeśli podasz),
- pobierze i skonfiguruje **GitHub Actions Runner** w trybie usługi.

> Token wygasa w ~60 minut. Jeśli się spóźnisz – wygeneruj skrypt ponownie.

## 3) Weryfikacja
W repo → **Settings → Actions → Runners** zobaczysz nowe hosty online.
W workflow dodaj:

```yaml
runs-on: [self-hosted, win-x64]  # lub macos-x64 / linux-x64
```

## 4) Dodatkowe: macOS/Linux bootstrap (opcjonalnie)
- **macOS:** `agent/scripts/mac-first.sh` – włącza SSH i (opcjonalnie) instaluje brew.
- **Linux:** `agent/playbooks/linux-bootstrap.yml` – instaluje Docker itd.

---

### Bezpieczeństwo
- Agent używa **ephemeral tokenów** GitHub (ważne ~60 min).
- SSH tylko na klucze (zalecane). Użyj parametru `--ssh-key` jeśli chcesz wgrać klucz.
- Porty publiczne? Rozważ **Cloudflare Tunnel** / **Tailscale** zamiast otwierania 22/TCP.

Powodzenia, Radziu. To jest praktyczny „prawie‑Codespaces”, ale na Twoim żelazie.
