Poziomy Pewności – szkic.
