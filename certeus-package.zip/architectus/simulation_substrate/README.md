simulation_substrate – stub
