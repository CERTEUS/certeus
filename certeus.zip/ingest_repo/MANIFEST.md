+=============================================================+
|                       CERTEUS — HEART                        |
+=============================================================+
# CERTEUS PACK MANIFEST

- Source: `F:\projekty\certeus`
- Packs: 3
- Files (ingested): 195
- Params: pack_chars=250000, file_chunk=80000, overlap=2000, safe=True

- **pack_01.txt** — chars: 257707, files: 96, sha256: `c2ff42d694d0…`
- **pack_02.txt** — chars: 257201, files: 76, sha256: `d82c79be91dc…`
- **pack_03.txt** — chars: 72278, files: 23, sha256: `397425a93b00…`
