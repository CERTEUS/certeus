Nexus::Verify – szkic.
