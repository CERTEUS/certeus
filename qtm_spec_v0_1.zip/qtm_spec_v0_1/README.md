
# qtm-spec v0.1 — Quantum Theory of Legal Measurement (CERTEUS)

Implements wavefunction/density-matrix formalism for legal cases:
- State |Ψ_case> over verdict/intent/consent bases
- Observables as Hermitian operators (W, I, C, L, T, ...)
- POVM measurements with collapse
- Uncertainty via commutators
- Entanglement detection (mutual information, negativity)
- Decoherence channels (dephasing, amplitude damping, depolarizing)

This complements `lexqft` (UV field theory & lattice) and `cfe` (IR geometry).
