
import numpy as np
from typing import Dict
from .state import HilbertSpace

def projector(H: HilbertSpace, label: str) -> np.ndarray:
    d = len(H.basis)
    i = H.basis.index(label)
    e = np.zeros((d,1), dtype=complex); e[i,0]=1.0
    return e @ e.conj().T

def hermitian_from_eigs(H: HilbertSpace, eigvals: Dict[str, float]) -> np.ndarray:
    d = len(H.basis)
    O = np.zeros((d,d), dtype=complex)
    for label,val in eigvals.items():
        P = projector(H, label)
        O += val * P
    return O

def commutator(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    return A@B - B@A

def uncertainty_lower_bound(rho: np.ndarray, A: np.ndarray, B: np.ndarray) -> float:
    C = commutator(A,B)
    # Robertson: ΔA ΔB ≥ 0.5 |Tr(rho [A,B])|
    v = np.trace(rho @ C)
    return 0.5*abs(v)
